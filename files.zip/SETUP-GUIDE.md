# Setup Guide: Firebase login, announcements and security rules

Folder contents
- `public/index.html` – the full website (all existing content kept) plus announcements system and staff dashboard
- `public/firebase-config.js` – YOU paste your Firebase web config here
- `public/firebase-shim.js` – connects the site to Firebase Auth and Firestore
- `firestore.rules` – database security rules
- `firebase.json` – hosting and rules settings

IMPORTANT: this package has NOT been tested against a live Firebase project. Do the checks in Step 8 before relying on it.

## Step 1 – Use your existing Firebase project
Open https://console.firebase.google.com and select the project that hosts your site.
Project settings (gear icon) > General > "Your apps". If there is no web app, click the `</>` icon and register one.
Copy the `firebaseConfig` values into `public/firebase-config.js` (replace every PASTE_... value). Do not invent values.

## Step 2 – Turn on login
Build > Authentication > Get started > Sign-in method > Email/Password > Enable.
Settings > User actions: if "Enable create (sign-up)" is shown, turn it OFF so strangers cannot create accounts.
Users tab > Add user: create your own account (email + strong password) and the chairman's account (his email + a temporary password you give him privately).

## Step 3 – Create the database
Build > Firestore Database > Create database > choose a location > Production mode.

## Step 4 – Publish the security rules
Firestore Database > Rules tab > replace everything with the contents of `firestore.rules` > Publish.
(Or, with the command line: `firebase deploy --only firestore:rules`.)

## Step 5 – Make your account the Website Administrator (one-time)
1. Authentication > Users > copy YOUR "User UID".
2. Firestore Database > Start collection > Collection ID: `roles`.
3. Document ID: paste your User UID. Add one field: `role` (string) = `admin`. Save.
This can only be done in the Console. The website cannot create administrators.

## Step 6 – Give the chairman access
1. The chairman opens `https://YOUR-SITE/#staff-login` and signs in with his email and password.
2. The page says "Signed in, but not authorized yet" and shows his User ID. He sends it to you.
3. You sign in at the same address > Admin button > Account & Access > paste his User ID > Authorize Chairman.
4. He signs in again and sees the dashboard. The chairman cannot change administrator accounts (the rules forbid it).
You can remove his access at any time from the same screen.

The private login address is `https://YOUR-SITE/#staff-login`. It is not linked anywhere on the public site. The Admin button appears only after a staff member signs in.

## Step 7 – Deploy
```
npm install -g firebase-tools
firebase login
firebase use --add        (choose your project)
firebase deploy
```
Run these commands inside this folder (the one containing firebase.json).

## Step 8 – Test before trusting it
1. Logged out (private window): the home page and Announcements load with no login.
2. As admin, post a draft: logged-out visitors must NOT see it. Publish it: it appears on the home page and on a phone.
3. Mark one announcement "Important" and give another a past expiry date: important ones show first on the home page; expired ones move to Archive.
4. Logged out, open `#admin`: you must be sent to the login page.
5. Logged out, try to post or delete: it must fail. Try the same in Firebase Console > Firestore > Rules playground (simulate unauthenticated write to `announcements`; it must be denied).
6. Sign in as chairman: can post/edit announcements; has no "Account & Access" tab; in the Rules playground, a write to `roles/<your admin UID>` as the chairman must be denied.
7. Refresh and check on another device: the data persists.

## What is and is not included
Included: announcements (categories, important label, attachment link, expiry, draft/publish/unpublish/archive/delete, home page preview with Read More, Archive tab), staff login, admin and chairman roles, complaints and messages inbox, research projects/resources editing, account management.
Not editable from the dashboard yet: class timetables (use the "Classes" announcement category), faculty, activities, programs, homepage text and contact details. These are still changed in the site files.
Complaint and contact forms are open to anyone (no login), so spam is possible. Consider enabling Firebase App Check later.
